package stack;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;



public class ass42 {
	
	static class pixel{
		int r,c;
		int[][] bl=new int[r][c];
		int[][] re=new int[r][c];
		int[][] gr=new int[r][c];
		int[][] grey=new int[r][c];
		
		pixel(int r,int c,int[][] bl,int[][] re,int[][] gr,int[][] grey) {
			this.r=r;
			this.c=c;
			this.bl=bl;
			this.gr=gr;
			this.re=re;
			this.grey=grey;
		}
		
		static int[][] add(int mat1[][],int mat2[][],int mat3[][], int r, int c){
	        int i, j;
	        int C[][] = new int[r][c];

	        for (i = 0; i <r; i++)
	            for (j = 0; j <c; j++)
	                C[i][j] = mat1[i][j] + mat2[i][j]+ mat3[i][j];

	        return C;
	    }
		
		static int[][] sub(int mat1[][],int mat2[][], int r, int c){
	        int i, j;
	        int C[][] = new int[r][c];

	        for (i = 0; i <r; i++)
	            for (j = 0; j <c; j++)
	                C[i][j] = mat1[i][j] - mat2[i][j];

	        return C;
	    }
		
		
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int r,c;
		pixel px=null;
		int y;
		String name;
		Map<String, pixel> pixel_data = new HashMap<>();
		
		System.out.println("------------------ Select Option ------------------------------------");
		System.out.println("1. Input a new Image");
		System.out.println("2. Update a Existing Image");
		System.out.println("3. Display the Image");
		System.out.println("4. Compute the negatives of Colured Image");
		System.out.println("5. Exit the Program");
		System.out.println("---------------------------------------------------------------------");
		System.out.println();
		System.out.println("Choose Option");
		y=sc.nextInt();
		while(y<6) {
			if(y==1) {
				System.out.println();
				sc.nextLine();
				System.out.println("Name of Image");
				name=sc.nextLine();
				System.out.println("Input the Resolution");
				System.out.println("No. of Rows");
				r=sc.nextInt();
				System.out.println("No. of Coloumn");
				c=sc.nextInt();
				
				int[][] bl=new int[r][c];
				int[][] re=new int[r][c];
				int[][] gr=new int[r][c];
				int[][] grey=new int[r][c];
				
				
				System.out.println();
				
				System.out.println("Intensity of Blue Colour");
				for(int i=0;i<r;i++) {
					for(int j=0;j<c;j++) {
						bl[i][j]=sc.nextInt();
					}
				}
				
				System.out.println();
				
				System.out.println("Intensity of RedColour");
				for(int i=0;i<r;i++) {
					for(int j=0;j<c;j++) {
						re[i][j]=sc.nextInt();
					}
				}
				
				
				System.out.println();
				System.out.println("Intensity of Green Colour");
				for(int i=0;i<r;i++) {
					for(int j=0;j<c;j++) {
						gr[i][j]=sc.nextInt();
					}
				}
				
				System.out.println();
				
				System.out.println("Intensity of Grey Colour");
				for(int i=0;i<r;i++) {
					for(int j=0;j<c;j++) {
						grey[i][j]=sc.nextInt();
					}
				}
				px=new pixel(r,c,bl,re,gr,grey);
				pixel_data.put(name, px);
				System.out.println("---------------------------------------------------------");
                System.out.println("Choose new option");
                y=sc.nextInt();
                continue;
				
			}
			if(y==2) {
					pixel mat = null;
					System.out.println("Name of Image");
	                sc.nextLine();
	                String m1=sc.nextLine();
	                for(Map.Entry<String, pixel> entry: pixel_data.entrySet()){
	                    if (entry.getKey().equals(m1)){
	                        mat = entry.getValue();
	                        break;
	                    }
	                }
	                System.out.println("Which Matrix to Update");
	                System.out.println("1. Red");
	                System.out.println("2. Green");
	                System.out.println("3. Blue");
	                System.out.println("4. Grey");
	                int m=sc.nextInt();
	                
	                if(m==1) {
	                	System.out.println("Re-input for Red Matrix");
	                	for(int i=0;i<mat.r;i++) {
	    					for(int j=0;j<mat.c;j++) {
	    						mat.re[i][j]=sc.nextInt();
	    					}
	    				}
	                	System.out.println("---------------------------------------------------------");
	                    System.out.println("Choose new option");
	                    y=sc.nextInt();
	                    continue;
	                }
	                
	                if(m==2) {
	                	System.out.println("Re-input for Green Matrix");
	                	for(int i=0;i<mat.r;i++) {
	    					for(int j=0;j<mat.c;j++) {
	    						mat.re[i][j]=sc.nextInt();
	    					}
	    				}
	                	System.out.println("---------------------------------------------------------");
	                    System.out.println("Choose new option");
	                    y=sc.nextInt();
	                    continue;
	                }
	                
	                if(m==3) {
	                	System.out.println("Re-input for Blue Matrix");
	                	for(int i=0;i<mat.r;i++) {
	    					for(int j=0;j<mat.c;j++) {
	    						mat.bl[i][j]=sc.nextInt();
	    					}
	    				}
	                	System.out.println("---------------------------------------------------------");
	                    System.out.println("Choose new option");
	                    y=sc.nextInt();
	                    continue;
	                }
	                if(m==4) {
	                	System.out.println("Re-input for Grey Matrix");
	                	for(int i=0;i<mat.r;i++) {
	    					for(int j=0;j<mat.c;j++) {
	    						mat.grey[i][j]=sc.nextInt();
	    					}
	    				}
	                	System.out.println("---------------------------------------------------------");
	                    System.out.println("Choose new option");
	                    y=sc.nextInt();
	                    continue;
	                }
	                
			}
			if(y==3) {
				pixel mat = null;
				System.out.println("Name of Image");
                sc.nextLine();
                String m1=sc.nextLine();
                for(Map.Entry<String, pixel> entry: pixel_data.entrySet()){
                    if (entry.getKey().equals(m1)){
                        mat = entry.getValue();
                        break;
                    }
                }
                System.out.println("---------------------------------------------------------");
                System.out.println("Which Matrix to Update");
                System.out.println("1. Red");
                System.out.println("2. Green");
                System.out.println("3. Blue");
                System.out.println("4. Comination of All Colours");
                System.out.println("5. Grey");
                System.out.println("6. Display All");
                System.out.println("---------------------------------------------------------");
                int m=sc.nextInt();
                
                if(m==1) {
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.re[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(m==2) {
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.gr[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(m==3) {
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.bl[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(m==4) {
                	int co[][]=new int[mat.r][mat.c];
                	co=mat.add(mat.bl,mat.gr,mat.re,mat.r,mat.c);
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(co[i][j]+"("+mat.re[i][j]+","+mat.gr[i][j]+","+mat.bl[i][j]+")  ");
    					}System.out.println();
    				}
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                	
                }
                if(m==5) {
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.grey[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(m==6) {
                	System.out.println("Matrix with Red Pixel");
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.re[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println();
                	System.out.println("Matrix with Green Pixel");
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.gr[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println();
                	System.out.println("Matrix with Blue Pixel");
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.bl[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println();
                	System.out.println("Matrix with Grey Pixel");
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(mat.grey[i][j]+" ");
    					}System.out.println();
    				}
                	System.out.println();
                	System.out.println("Coloured Image");
                	int co[][]=new int[mat.r][mat.c];
                	co=mat.add(mat.bl,mat.gr,mat.re,mat.r,mat.c);
                	for(int i=0;i<mat.r;i++) {
    					for(int j=0;j<mat.c;j++) {
    						System.out.print(co[i][j]+"("+mat.re[i][j]+","+mat.gr[i][j]+","+mat.bl[i][j]+")  ");
    					}System.out.println();
    				}
                	System.out.println();
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
            }
			
			if(y==4) {
				pixel mat = null;
				System.out.println("Name of Image");
                sc.nextLine();
                String m1=sc.nextLine();
                for(Map.Entry<String, pixel> entry: pixel_data.entrySet()){
                    if (entry.getKey().equals(m1)){
                        mat = entry.getValue();
                        break;
                    }
                }
                int upp[][]=new int[mat.r][mat.c];
                for(int i=0;i<mat.r;i++) {
                	for(int j=0;j<mat.c;j++) {
                		upp[i][j]=255;
                	}
                }
                System.out.println("Which Matrix Negative to find");
                System.out.println("1. Red");
                System.out.println("2. Green");
                System.out.println("3. Blue");
                System.out.println("4. Comination of All Colours");
                
                int l=sc.nextInt();
                if(l==1) {
                	int po[][]=new int[mat.r][mat.c];
                	po=mat.sub(upp,mat.re, mat.r, mat.c);
                	for(int i=0;i<mat.r;i++) {
                    	for(int j=0;j<mat.c;j++) {
                    		System.out.print(po[i][j]+" ");
                    	}System.out.println();
                    }
                	System.out.println();
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(l==2) {
                	int po[][]=new int[mat.r][mat.c];
                	po=mat.sub(upp,mat.gr,mat.r, mat.c);
                	for(int i=0;i<mat.r;i++) {
                    	for(int j=0;j<mat.c;j++) {
                    		System.out.print(po[i][j]+" ");
                    	}System.out.println();
                    }
                	System.out.println();
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(l==3) {
                	int po[][]=new int[mat.r][mat.c];
                	po=mat.sub(upp,mat.bl, mat.r, mat.c);
                	for(int i=0;i<mat.r;i++) {
                    	for(int j=0;j<mat.c;j++) {
                    		System.out.print(po[i][j]+" ");
                    	}System.out.println();
                    }
                	System.out.println();
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
                if(l==4) {
                	int co[][]=new int[mat.r][mat.c];
                	co=mat.add(mat.bl,mat.gr,mat.re,mat.r,mat.c);
                	int po[][]=new int[mat.r][mat.c];
                	po=mat.sub(upp,co, mat.r, mat.c);
                	for(int i=0;i<mat.r;i++) {
                    	for(int j=0;j<mat.c;j++) {
                    		System.out.print(po[i][j]+" ");
                    	}System.out.println();
                    }
                	System.out.println();
                	System.out.println("---------------------------------------------------------");
                    System.out.println("Choose new option");
                    y=sc.nextInt();
                    continue;
                }
            }
			if(y==5) {
				System.out.println("Program Ended");
            	System.out.println("---------------------------------------------------------");
            	return;
            }
		}
		
		
		
		

	}

}
