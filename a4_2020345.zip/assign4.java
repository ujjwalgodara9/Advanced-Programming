package stack;
import java.util.*;

public class assign4 {

	
		
		static class library{
			int n,k;
			String name;
			long isbn;
			Long bar;
			
			library(String name,long isbn2, Long bar2){
				
				this.name=name;
				this.isbn=isbn2;
				this.bar=bar2;
			}
			library(int n,int k)
			{
				this.n=n;
				this.k=k;
			}
		}
		public static Long generateRandom() {
		    Random random = new Random();
		    StringBuilder sb = new StringBuilder();

		    // first not 0 digit
		    sb.append(random.nextInt(9) + 1);

		    // rest of 11 digits
		    for (int i = 0; i < 11; i++) {
		        sb.append(random.nextInt(10));
		    }

		    return (Long) Long.parseLong(sb.toString());
		}
		
	

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			int k,n;
			int z=0;
			int y=0;
			int counter = 0;
			library lib=null;
			String name;
			long isbn;
			Long bar;
			Map<String, library> lib_name = new HashMap<>();
			ArrayList<String> str=new ArrayList<>();
			System.out.println("----------------------------------------------------------------");
			System.out.println("Number of racks");
			k=sc.nextInt();
			System.out.println("Number of Books");
			n=sc.nextInt();
			library[] books = new library[n];
			library[] sorted = new library[n];
			
			while(n%k!=0) {
				System.out.println("Invalid no of books and racks");
				System.out.println("-----------------------------------------------------------");
				System.out.println("Number of racks");
				k=sc.nextInt();
				System.out.println("Number of Books");
				n=sc.nextInt();
			}
			System.out.println("---------------------------------------------------------------");
			System.out.println("1. Add books");
			System.out.println("2. Order the Books in Correct Order");
			System.out.println("3. Print Books in order way");
			System.out.println("4. Fnd the position of a particular book");
			System.out.println("---------------------------------------------------------------");
			while(z!=-1) {
				System.out.println("enter choice:");
				y=sc.nextInt();
				if(y==1) {
					for (int i = 0; i < n; i++) {
						System.out.println("Input details of Book no. " + i + 1);
						sc.nextLine();
						System.out.println("Name of Book");
						name = sc.nextLine();
						System.out.println("ISBN Number of book");
						isbn = sc.nextLong();
						int count = 0; 
						Long num = isbn;
						while (num != 0) {
					      num /= 10;
					      ++count;
					    }
						
						while(count!=12) {
							System.out.println();
							System.out.println("Wrong ISBN Input");
							System.out.println("Again give ISBN no.");
							isbn=sc.nextLong();
							num = isbn;
							count=0;
							while (num != 0) {
							      num /= 10;
							      ++count;
							    }
						}
						bar = generateRandom();
						str.add(name);

						lib = new library(name, isbn, bar);
						lib_name.put(name, lib);
						books[counter] = lib;
						counter++;
						System.out.println();
					}
					System.out.println("---------------------------------------------------------------");
					continue;
				}
				if (y==2){

					for (int i =0;i<n;i++) {
						library temp = books[i];
						int smallest_loc = 0;
						for (int j =i; j < n; j++){
							if (books[j].name.compareTo(temp.name) < 0) {
								temp = books[j];
								smallest_loc = j;
							} else if (books[j].name.compareTo(temp.name) == 0) {
								if (books[j].isbn < books[i].isbn) {
									temp = books[j];
									smallest_loc = j;
								} else if (books[j].isbn==books[i].isbn) {
									if (books[j].bar < books[i].bar) {
										temp = books[j];
										smallest_loc = j;
									}
								}
							}
						}
						books[smallest_loc] = books[i];
						sorted[i] = temp;
					}
					System.out.println("Book Ordered in Correct Order");
					System.out.println("---------------------------------------------------------------");
					continue;
				}
					if(y==3) {
						for (int i=0;i<n;i++){
							System.out.println("Book Name: "+sorted[i].name);
							System.out.println("Book ISBN: "+sorted[i].isbn);
							System.out.println("Book BARCODE: "+sorted[i].bar);
							System.out.println();
						}
						System.out.println("---------------------------------------------------------------");
						continue;
					}
					if(y==4) {
						System.out.println("Name of book to find in Library");
						sc.nextLine();
						
						String search=sc.nextLine();
						int v = 1;
						int h=1;
						int m=0;
						for(int i=0;i<n;i++) {
							if(sorted[i].name.equals(search)) {
								System.out.println("It is present in Rack No. "+v + " and book No is "+h);
							}
							h++;
							m++;
							if(n/k==m) {
								v++;
								h=1;
								m=0;
							}
							
							
						}
						
						System.out.println("---------------------------------------------------------------");
						continue;
					}
					else {
						System.out.println("Program Ended");
						System.out.println("---------------------------------------------------------------");
						return;
					}
			}
		}
	}


